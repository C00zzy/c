#include <stdio.h>

#include "tests.h"

int main(void)
{
    test_isalpha();
    test_isdigit();
    test_isalnum();
    test_areupper();
    printf(":)\n");
}
