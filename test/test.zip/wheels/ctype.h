#include <stdbool.h>

bool isalpha(char c);
bool isdigit(char c);
bool isalnum(char c);
bool areupper(char *s);
